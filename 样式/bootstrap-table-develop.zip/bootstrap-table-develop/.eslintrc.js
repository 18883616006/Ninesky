module.exports = {
    "extends": "standard",
    "globals": {
      "jQuery": true,
      "$": true
    }
};
